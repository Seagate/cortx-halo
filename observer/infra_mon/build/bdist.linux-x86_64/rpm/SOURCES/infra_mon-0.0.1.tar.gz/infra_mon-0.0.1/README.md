

# Halo Infra Monitor


## Installation Steps

cd infra/mon/
python3 setup.py bdist_rpm
cd dist
yum install -y infra_mon-0.0.1*.noarch.rpm


## Thank You!